/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padel;

import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;
import java.text.SimpleDateFormat;  
import java.util.Date;  

/**
 *
 * @author victo
 */
public class Padel {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        

        try (Connection conn = DriverManager.getConnection(
             // Oracle SID = orcl , find yours in tnsname.ora
            "jdbc:oracle:thin:@oracle0.ugr.es:1521/practbd.oracle0.ugr.es", "X4119634", "X4119634")) {

            if (conn != null) {
                System.out.println("Conectado!");
            }
            else
            {
                System.out.println("Error al conectar!");
            }
        
        conn.setAutoCommit(false);

        //Execute

        
        Statement st = conn.createStatement();
        
        // ResultSet rs = null;
        Scanner sn = new Scanner(System.in);
        boolean salir = false;
        int opcion; //Guardaremos la opcion del usuario
        
        while(!salir){
            
            System.out.println("----- P3 DDSI - MENÚ -----");
            System.out.println("1. Mostrar jugadores no inscritos en una edición");
            System.out.println("2. Iniciar compra ");
            System.out.println("3. Crear una contraoferta");
            System.out.println("4. Insertar partido");
            System.out.println("5. Salir del programa y cerrar conexión a BD");


            System.out.println("Escribe una de las opciones");
            opcion = sn.nextInt();

            
            switch(opcion){
                case 1:
                    System.out.println("Has seleccionado la opcion 1");

                    System.out.println("Introduzca un año para mostrar los jugadores no inscritos");
                    Scanner scan_anio = new Scanner(System.in);
                    int edicion = scan_anio.nextInt();
                    ArrayList<Integer> idjugadoresIns = new ArrayList<Integer>();
                    ArrayList<Integer> idjugadores = new ArrayList<Integer>();
                    ResultSet rs = st.executeQuery("SELECT id_jugador1,id_jugador2 FROM Pareja_Participando_Edicion WHERE Anio=" + edicion);
                    while(rs.next()){
                        idjugadoresIns.add(rs.getInt("id_jugador1"));
                        idjugadoresIns.add(rs.getInt("id_jugador2"));
                    }
                    rs = st.executeQuery("SELECT id_jugador FROM Jugador");
                    while(rs.next()){
                        idjugadores.add(rs.getInt("id_jugador"));
                    }
                                        
                    for(int id: idjugadoresIns){
                        idjugadores.remove(idjugadores.indexOf(id));
                    }
                    System.out.println("Jugadores no inscritos en el año " + edicion);
                    for(int id: idjugadores){
                        rs = st.executeQuery("SELECT Nombre, Apellidos FROM Jugador WHERE id_jugador=" + id);
                        rs.next();
                        System.out.println(id + " " + rs.getString("Nombre") + " " + rs.getString("Apellidos"));
                    }
                    conn.commit();                    
                    
                    break;
                case 2:
                    System.out.println("Has seleccionado la opcion 2");
                    
                    System.out.println("Introduzca su número de cliente");
                    Scanner cod_cli = new Scanner(System.in);
                    String cod_cliente = cod_cli.nextLine();
                    
                    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
                    Date date = new Date();
    
                    int anio = Calendar.getInstance().get(Calendar.YEAR);
    
                    String fecha = formatter.format(date);
                    
                    st.executeQuery("INSERT INTO Compra(Fecha_inicio, id_usuario) VALUES (to_date('"+fecha+"', 'DD/MM/YYYY HH24:MI:SS'),"+cod_cliente+") ");
                    
                    conn.commit();
                    
                    ResultSet c2 = st.executeQuery("SELECT id_compra FROM Compra WHERE fecha_inicio=to_date('"+fecha+"', 'DD/MM/YYYY HH24:MI:SS')");
                    String id_compra_actual = "";            
                    
                    while (c2.next()) {
                        id_compra_actual = c2.getString("id_compra");
                    }
                    System.out.println("Usuario: " + cod_cliente + " ID generado es " + id_compra_actual);
                        
                    st.executeQuery(" INSERT INTO Pertenece VALUES('"+id_compra_actual+"', '"+anio+"') ");
                    break;
                case 3:
                    System.out.println("Has seleccionado la opcion 3");

                    System.out.println("Introduzca la oferta que quiere contraofertar");
                    Scanner sc_id = new Scanner(System.in);
                    int oferta_leida = -1, id_oferta;
                    do{
                        id_oferta = Integer.parseInt(sc_id.nextLine());
                        ResultSet rs_1 = st.executeQuery("SELECT id_oferta FROM OFERTA WHERE id_oferta="+ id_oferta);
                        while (rs_1.next()){
                            oferta_leida = rs_1.getInt("id_oferta");
                        }
                    }while(id_oferta != oferta_leida);
                    
                    
                    System.out.println("Introduzca el dinero por el que realizara la contraoferta");
                    Scanner sc_dinero = new Scanner(System.in);
                    int n_dinero = Integer.parseInt(sc_dinero.nextLine());
                    
                    st.executeQuery("INSERT INTO CONTRAOFERTA(id_oferta,n_dinero,f_contraoferta) VALUES ("+id_oferta+","+n_dinero+",SYSDATE)");
                    
                    conn.commit();


                    break;
                case 4:
                    System.out.println("Has seleccionado la opcion 4");

                    System.out.println("Introduzca el numero del partido");
                    Scanner num_partido = new Scanner(System.in);
                    int num_p = Integer.parseInt(num_partido.nextLine());
                    
                    System.out.println("Introduzca el numero de sets locales");
                    Scanner sets_locales = new Scanner(System.in);
                    int setl = Integer.parseInt(sets_locales.nextLine());
                    
                    System.out.println("Introduzca el numero de sets del equipo visitante");
                    Scanner sets_visi = new Scanner(System.in);
                    int setv = Integer.parseInt(sets_visi.nextLine());
                    
                    System.out.println("Introduzca el numero de la pista");
                    Scanner spista = new Scanner(System.in);
                    int pista = Integer.parseInt(spista.nextLine());
                    
                    System.out.println("Introduzca el árbitro (id_arbitro)");
                    Scanner sarbi = new Scanner(System.in);
                    int arbitro = Integer.parseInt(sarbi.nextLine());
                    
                    SimpleDateFormat formatter2 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                    Date date_partido = new Date();
                    int anio_partido = Calendar.getInstance().get(Calendar.YEAR);
                    
                    String fecha_partido = formatter2.format(date_partido);
                    
                    st.executeQuery(" INSERT INTO Partido VALUES ('"+num_p+"',to_date('"+fecha_partido+"', 'DD/MM/YYYY HH24:MI:SS'),'"+setl+"','"+setv+"','"+pista+"','"+anio_partido+"','"+arbitro+"') ");
                    conn.commit();
  
                    break;
                case 5:
                    sn.close();
                    conn.close();
                    System.out.println("Cerrada la conexión");
                    salir=true;
                    break;
                    default:
                    System.out.println("Solo números entre 1 y 5");
            }

        }


        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
            System.err.format("SQL State: %s\n", e.getErrorCode());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }

}
